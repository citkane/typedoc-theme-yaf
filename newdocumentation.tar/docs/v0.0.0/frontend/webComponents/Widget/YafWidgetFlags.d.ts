import { yafWidgetFlagsProps } from '../../../types/frontendTypes.js';
import { YafHTMLElement } from '../../index.js';
export declare class YafWidgetFlags extends YafHTMLElement<yafWidgetFlagsProps> {
    onConnect(): void;
}
