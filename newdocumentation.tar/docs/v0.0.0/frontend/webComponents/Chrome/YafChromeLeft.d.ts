import { YafHTMLElement } from '../../index.js';
/**
 *
 */
export declare class YafChromeLeft extends YafHTMLElement {
    onConnect(): void;
    disconnectedCallback(): void;
    private toggleSearch;
    private eventsList;
}
