import YafHTMLElement from '../../YafHTMLElement.js';
/**
 *
 */
export declare class YafNavigationSearchbar extends YafHTMLElement {
    onConnect(): void;
    disconnectedCallback(): void;
    private focussed;
    private blurred;
    private changed;
    private static factory;
}
