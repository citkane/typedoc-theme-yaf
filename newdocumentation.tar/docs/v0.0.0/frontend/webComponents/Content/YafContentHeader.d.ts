import { YAFDataObject } from '../../../types/types.js';
import { YafHTMLElement } from '../../index.js';
export declare class YafContentHeader extends YafHTMLElement<YAFDataObject> {
    onConnect(): void;
}
