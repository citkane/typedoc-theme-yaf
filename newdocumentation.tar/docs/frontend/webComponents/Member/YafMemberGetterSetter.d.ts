import { YAFDataObject } from '../../../types/types.js';
import { YafHTMLElement } from '../../index.js';
export declare class YafMemberGetterSetter extends YafHTMLElement<YAFDataObject> {
    onConnect(): void;
    private static factory;
}
