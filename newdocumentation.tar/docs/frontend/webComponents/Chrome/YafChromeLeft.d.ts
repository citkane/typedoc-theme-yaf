import { YafHTMLElement } from '../../index.js';
/**
 *
 */
export declare class YafChromeLeft extends YafHTMLElement {
    onConnect(): void;
}
