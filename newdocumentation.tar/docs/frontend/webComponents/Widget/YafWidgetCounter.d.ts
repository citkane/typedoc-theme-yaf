import { yafWidgetCounterProps } from '../../../types/frontendTypes.js';
import { YafHTMLElement } from '../../index.js';
export declare class YafWidgetCounter extends YafHTMLElement<yafWidgetCounterProps> {
    onConnect(): void;
}
