import { YafHTMLElement } from '../../index.js';
export declare class YafNavigationLink extends YafHTMLElement {
    aHTMLElement: HTMLAnchorElement;
    onConnect(): void;
    disconnectedCallback(): void;
    private static factory;
}
