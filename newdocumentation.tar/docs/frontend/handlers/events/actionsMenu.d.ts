import { scrollTo } from './index.js';
export declare const rollMenuDown: () => Event;
export declare const rollMenuUp: () => Event;
export interface menu {
    scrollTo: scrollTo;
    rollMenuDown: null;
    rollMenuUp: null;
}
