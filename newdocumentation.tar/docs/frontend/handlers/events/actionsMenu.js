import { trigger } from './triggers.js';
export const rollMenuDown = () => new Event(trigger.menu.rollMenuDown);
export const rollMenuUp = () => new Event(trigger.menu.rollMenuUp);
//# sourceMappingURL=actionsMenu.js.map