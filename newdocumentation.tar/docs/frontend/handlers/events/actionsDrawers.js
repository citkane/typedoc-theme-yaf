import { trigger } from './triggers.js';
export const resetDrawerHeight = () => new Event(trigger.drawers.resetHeight);
//# sourceMappingURL=actionsDrawers.js.map